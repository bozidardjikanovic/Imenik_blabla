import React, { useState, useEffect } from 'react';

function Imenik() {
  const [zapisi, setZapisi] = useState([]);
  const [ime, setIme] = useState('');
  const [telefon, setTelefon] = useState('');

  useEffect(() => {
    const storedZapisi = localStorage.getItem('zapisi');
    if (storedZapisi) {
      setZapisi(JSON.parse(storedZapisi));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('zapisi', JSON.stringify(zapisi));
  }, [zapisi]);

  const dodajZapis = () => {
    if (ime && telefon && validacija()) {
      setZapisi(prevZapisi => [
        ...prevZapisi,
        {
          ime: ime,
          telefon: telefon
        }
      ]);
      setIme('');
      setTelefon('');
    }
  };

  const obrisiZapis = (index) => {
    setZapisi(prevZapisi => {
      const newZapisi = [...prevZapisi];
      newZapisi.splice(index, 1);
      return newZapisi;
    });
  };

  const validacija = () => {
    return /^\d{10}$/.test(telefon);
  };

  return (
    <div>
      <h1>Imenik</h1>

      <ul>
        {zapisi.map((zapis, index) => (
          <li key={index}>
            {zapis.ime} - {zapis.telefon}
            <button onClick={() => obrisiZapis(index)}>Obriši</button>
          </li>
        ))}
      </ul>

      <div>
        <input type="text" value={ime} onChange={(e) => setIme(e.target.value)} placeholder="Ime" />
        <input type="text" value={telefon} onChange={(e) => setTelefon(e.target.value)} placeholder="Broj telefona" />
        <button onClick={dodajZapis}>Dodaj</button>
        {!validacija() && <p>Niste uneli ispravan broj telefona!</p>}
      </div>
    </div>
  );
}

export default Imenik;
